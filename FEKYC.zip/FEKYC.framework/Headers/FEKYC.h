//
//  FEKYC.h
//  FEKYC
//
//  Created by The New Macbook on 3/3/20.
//  Copyright © 2020 fpt. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FEKYC.
FOUNDATION_EXPORT double FEKYCVersionNumber;

//! Project version string for FEKYC.
FOUNDATION_EXPORT const unsigned char FEKYCVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FEKYC/PublicHeader.h>


