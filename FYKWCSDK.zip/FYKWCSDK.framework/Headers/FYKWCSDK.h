//
//  FYKWCSDK.h
//  FYKWCSDK
//
//  Created by The New Macbook on 3/6/20.
//  Copyright © 2020 fpt. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FYKWCSDK.
FOUNDATION_EXPORT double FYKWCSDKVersionNumber;

//! Project version string for FYKWCSDK.
FOUNDATION_EXPORT const unsigned char FYKWCSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FYKWCSDK/PublicHeader.h>


